# Entity Hunter
- [x] Filter technical names and non-contact URLs, simplify entity cards, preserve official reporting channels, and verify real investigations and notification selection: 65 tests passed; Cloudflare domain and APNIC IP, notice generation, navigation, light/dark themes and mobile presentation verified.
- [x] Interface, navigation, light/dark themes and investigation states.
- [x] Safe URL parsing and real IANA RDAP / DNS queries.
- [x] Public IP RDAP, ASN enrichment and entity normalization (RIPEstat; no Team Cymru integration).
- [x] Recipient selection and editable notification templates.
- [x] Tests and real desktop/mobile investigation verification: 27 tests passed; Registro.br and Cloudflare investigated successfully; recipient changes, editable notices, clipboard and persisted theme verified.
- [x] Resolve verified notification contacts, official channels and RDAP related entities; restrict result categories and suppress unsupported recipients.
- [x] Add locally persisted Templates editor and connect saved models to generation.
- [x] Test investigation, contact ownership, selection, template persistence and notification generation on desktop/mobile: 48 tests passed; Cloudflare domain and APNIC IP verified with published abuse contacts; model edits, reload, generation, creation, restoration and manual notice edits verified.