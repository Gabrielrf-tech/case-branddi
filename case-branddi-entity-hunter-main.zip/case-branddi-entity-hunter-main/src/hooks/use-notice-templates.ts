import { useEffect, useState } from 'react';
import { defaultTemplates, parseStoredTemplates, saveTemplates, templateStorageKey, type NoticeTemplate } from '@/lib/notification-templates';
export function useNoticeTemplates() {
  const [templates, setTemplates] = useState<NoticeTemplate[]>(defaultTemplates);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    try { setTemplates(parseStoredTemplates(localStorage.getItem(templateStorageKey))); } catch { setError('Armazenamento local indisponível. Alterações não poderão ser salvas.'); }
    setReady(true);
  }, []);
  function persist(next: NoticeTemplate[]) {
    try { saveTemplates(localStorage, next); setTemplates(next); setError(''); return true; }
    catch { setError('Não foi possível salvar neste navegador. Verifique as permissões ou o espaço disponível.'); return false; }
  }
  return { templates, ready, error, persist };
}
