import { describe, expect, it } from 'vitest';
import { parseTarget, isPublicIP } from '@/lib/investigation/domain';
import { generateNotice } from '@/lib/notification-templates';
import { mergeEntities, normalizeRDAP, notificationEntities, sortContacts, registrarReferral } from '@/lib/investigation/rdap.server';
import { registerRDAPServers, safeRDAPRedirect, isOfficialRDAPEntityURL } from '@/lib/investigation/http.server';

import { categories, type Contact } from '@/lib/investigation/types';
import { addOfficialContacts } from '@/lib/investigation/official-contacts.server';
import { isIdentifiableRecipientName, isUsefulContact, notificationRecipients } from '@/lib/investigation/recipient';

describe('Target rules', () => {
 it('permits RDAP referrals only to official HTTPS servers', () => {
  registerRDAPServers(['https://rdap.registro.br/']);
  const from = new URL('https://rdap.lacnic.net/rdap/ip/200.160.2.3');
  expect(safeRDAPRedirect('https://rdap.registro.br/ip/200.160.2.3', from).hostname).toBe('rdap.registro.br');
  expect(() => safeRDAPRedirect('http://rdap.registro.br/ip/200.160.2.3', from)).toThrow();
  expect(() => safeRDAPRedirect('https://127.0.0.1/ip/200.160.2.3', from)).toThrow();
  expect(() => safeRDAPRedirect('https://attacker.com/ip/200.160.2.3', from)).toThrow();
 });
 it('preserves original URL and uses PSL for .com.br', () => { expect(parseTarget('http://shop.exemplo.com.br/pagina')).toMatchObject({ originalUrl: 'http://shop.exemplo.com.br/pagina', hostname: 'shop.exemplo.com.br', domain: 'exemplo.com.br' }); });
 it('accepts protocol-free public domains', () => { expect(parseTarget('exemplo.com.br').domain).toBe('exemplo.com.br'); });
 it('rejects protocols other than HTTP and HTTPS', () => { expect(() => parseTarget('ftp://example.com')).toThrow(); });
 it.each(['localhost', 'http://127.0.0.1', 'http://10.0.0.1', 'http://192.168.1.1', 'http://169.254.169.254', 'http://[::1]', 'http://[fc00::1]', 'http://[::ffff:127.0.0.1]', 'http://2130706433', 'http://0x7f000001', 'http://192.0.2.1', 'http://[2001:db8::1]', 'http://224.0.0.1'])('blocks internal or reserved target %s', input => { expect(() => parseTarget(input)).toThrow(); });
 it('excludes reserved IPs from enrichment', () => { expect(isPublicIP('172.16.1.1')).toBe(false); expect(isPublicIP('1.1.1.1')).toBe(true); });
});
const input = { recipient: 'Registrar X', category: 'Registrar' as const, incident: 'Phishing', client: 'Globo', brand: 'G1', sameName: false, details: '', url: 'https://exemplo.com.br' };
describe('Notification rules', () => {
 it('keeps independent client and brand values', () => { expect(generateNotice(input).body).toContain('Globo, proprietária da marca G1'); });
 it('uses client as brand when the checkbox is enabled', () => { const notice = generateNotice({ ...input, sameName: true }); expect(notice.body).toContain('Marca afetada: Globo'); expect(notice.body).not.toContain('G1'); });
 it('does not use DMCA for phishing', () => { expect(generateNotice(input).body).not.toContain('DMCA'); });
 it('uses the copyright-specific template only for copyright', () => { expect(generateNotice({ ...input, incident: 'DMCA / Violação de direitos autorais' }).body).toContain('não substitui uma notificação DMCA formal'); });
 it('varies the request for network recipients without claiming hosting', () => { expect(generateNotice({ ...input, category: 'ISP' }).body).toContain('não comprova a hospedagem de origem'); });
});
const source = 'https://rdap.arin.net/registry/ip/1.1.1.1';
const card = (name: string, email?: string) => ['vcard', [['fn', {}, 'text', name], ...(email ? [['email', {}, 'text', email]] : [])]];
describe('Entity rules', () => {
 it.each(['1.1.1.1', '2001:4860:4860::8888', '1.1.1.0/24', '2001:4860::/32', '1.1.1.0 – 1.1.1.255', 'NET-1-1-1-0-1', 'AS13335', 'AS13335 · Organização não informada'])('suppresses technical recipient name %s even with a published email', name => {
  const records = normalizeRDAP({ objectClassName: 'ip network', entities: [{ objectClassName: 'entity', roles: ['registrant'], vcardArray: card(name, 'abuse@example.com') }] }, source, '', '');
  expect(notificationEntities(records)).toEqual([]);
 });
 it.each(['ip network', 'autnum'])('rejects a nested technical %s object regardless of its name and contact', objectClassName => {
  expect(normalizeRDAP({ entities: [{ objectClassName, roles: ['registrant'], vcardArray: card('Example Network', 'abuse@example.com') }] }, source, '', '')).toEqual([]);
 });
 it('accepts an identified organization rather than its network label', () => {
  const entities = normalizeRDAP({ objectClassName: 'ip network', name: '1.1.1.0/24', entities: [{ objectClassName: 'entity', roles: ['registrant'], vcardArray: ['vcard', [['fn', {}, 'text', '1.1.1.0/24'], ['org', {}, 'text', 'Example Network Ltd.'], ['email', {}, 'text', 'abuse@example.com']]] }] }, source, '', '');
  expect(notificationEntities(entities).map(entity => [entity.name, entity.category])).toEqual([['Example Network Ltd.', 'ISP']]);
 });
 it.each(['https://rdap.arin.net/registry/ip/1.1.1.1', 'https://data.iana.org/rdap/dns.json', 'https://rdap.apnic.net/entity/ORG-X'])('does not treat technical query %s as a contact', url => {
  expect(isUsefulContact({ type: 'official-contact', url, source, value: url, label: 'Canal oficial' })).toBe(false);
 });
 it('keeps technical provenance internally while retaining useful email, phone and form contacts', () => {
  const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Example Registrar', 'abuse@example.com') }] }, source, '', '')[0];
  if (!entity) throw new Error('Expected recipient');
  const contacts: Contact[] = [entity.contacts[0] as Contact, { type: 'official-contact', url: 'tel:+551130001000', value: '+55 11 3000-1000', source, label: 'Telefone' }, { type: 'abuse-form', url: 'https://example.com/reporting-abuse/', value: 'Denunciar abuso', source, label: 'Formulário' }, { type: 'official-contact', url: source, value: source, source, label: 'Consulta' }];
  const recipients = notificationRecipients([{ ...entity, contacts }]);
  expect(recipients[0]?.contacts.map(contact => contact.url)).toEqual(['mailto:abuse@example.com', 'tel:+551130001000', 'https://example.com/reporting-abuse/']);
  expect(recipients[0]?.sources).toEqual([source]);
  expect(contacts).toHaveLength(4);
 });
 it('applies recipient rules to results even when normalization was bypassed', () => {
  const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Example Registrar', 'report@example.com') }] }, source, '', '')[0];
  if (!entity) throw new Error('Expected recipient');
  expect(notificationRecipients([{ ...entity, name: '1.1.1.0/24' }])).toEqual([]);
  expect(isIdentifiableRecipientName('Example Registrar')).toBe(true);
 });
 it('preserves the Cloudflare reporting-abuse page as an official notification channel', () => {
  const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Cloudflare, Inc.') }] }, source, '', '')[0];
  if (!entity) throw new Error('Expected recipient');
  expect(notificationEntities([addOfficialContacts(entity)])[0]?.contacts).toContainEqual(expect.objectContaining({ type: 'official-contact', url: 'https://www.cloudflare.com/trust-hub/reporting-abuse/' }));
 });
 it('keeps only the six requested categories', () => { expect(categories).toEqual(['Domínio', 'Registrant', 'ISP', 'Registrar', 'Registry', 'Hosting Provider']); });
 it('suppresses entities without a verifiable notification channel', () => { expect(notificationEntities(normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Example Registrar') }] }, source, '2026-11-13', 'Registro'))).toEqual([]); });
 it('does not invent emails', () => { const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Example Registrar') }] }, source, '2026-11-13', 'Registro')[0]; expect(entity?.contacts).toEqual([]); });
 it('rejects handles as organization names and redacted names', () => { expect(normalizeRDAP({ entities: [{ handle: 'ORG', roles: ['registrar'] }, { roles: ['registrant'], vcardArray: card('DATA REDACTED', 'contact@example.com') }] }, source, '', '')).toEqual([]); });
 it('inherits explicitly nested abuse contacts with their own provenance', () => {
  const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Registrar A', 'notify@example.com'), entities: [{ roles: ['abuse'], vcardArray: card('Abuse', 'reports@example.com'), _contactSource: 'https://rdap.arin.net/registry/entity/ABUSE' }] }] }, source, '', '')[0];
  expect(entity?.contacts[0]).toMatchObject({ type: 'abuse-email', value: 'reports@example.com', source: 'https://rdap.arin.net/registry/entity/ABUSE' });
 });
 it('does not label administrative email as abuse or notification email', () => { const entity = normalizeRDAP({ entities: [{ roles: ['registrant'], vcardArray: card('Org'), entities: [{ roles: ['administrative'], vcardArray: card('Admin', 'admin@example.com') }] }] }, source, '', '')[0]; expect(entity?.contacts[0]?.type).toBe('official-contact'); expect(entity?.abuseEmails).toEqual([]); });
 it('does not transfer contact from a separately identified organization', () => { const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Org A'), entities: [{ roles: ['registrant'], vcardArray: card('Org B', 'other@example.com') }] }] }, source, '', '')[0]; expect(entity?.contacts).toEqual([]); });
 it('does not globally attach unrelated sibling abuse contacts', () => { const entities = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Org A') }, { roles: ['abuse'], vcardArray: card('Abuse', 'other@example.com') }] }, source, '', ''); expect(entities[0]?.contacts).toEqual([]); });
 it('keeps network recipients under ISP without claiming hosting', () => { const entities = normalizeRDAP({ objectClassName: 'ip network', entities: [{ roles: ['registrant'], vcardArray: card('Cloudflare, Inc.', 'notify@example.com') }] }, source, '', 'Bloco'); expect(entities[0]?.category).toBe('ISP'); expect(entities[0]?.relation).toContain('não comprova hospedagem'); });
 it('preserves all sources when deduplicating the same entity', () => { const make = (url: string) => normalizeRDAP({ entities: [{ handle: 'ORG', roles: ['registrar'], vcardArray: card('Org', 'report@example.com') }] }, url, '', ''); const merged = mergeEntities([...make(source), ...make('https://rdap.apnic.net/ip/1.1.1.1')]); expect(merged).toHaveLength(1); expect(merged[0]?.sources).toHaveLength(2); });
 it('prioritizes abuse email, notification email, official form, then other channels', () => { const contact = (type: Contact['type']) => ({ type, url: `https://example.com/${type}`, source, value: type, label: type }); expect(sortContacts(['official-contact', 'abuse-form', 'notification-email', 'abuse-email'].map(type => contact(type as Contact['type']))).map(c => c.type)).toEqual(['abuse-email', 'notification-email', 'abuse-form', 'official-contact']); });
 it('applies Cloudflare official channels only to the identified organization and proper role', () => { const entity = normalizeRDAP({ entities: [{ roles: ['registrar'], vcardArray: card('Cloudflare, Inc.') }] }, source, '', '')[0]; if (!entity) throw new Error('Expected entity'); expect(addOfficialContacts(entity).contacts[0]?.value).toBe('registrar-abuse@cloudflare.com'); expect(addOfficialContacts({ ...entity, name: 'Unrelated Organization' }).contacts).toEqual([]); expect(addOfficialContacts({ ...entity, category: 'ISP' }).contacts.some(c => c.value === 'registrar-abuse@cloudflare.com')).toBe(false); });
 it('does not follow arbitrary entity URLs', () => { registerRDAPServers(['https://rdap.arin.net/']); expect(isOfficialRDAPEntityURL('https://attacker.com/entity/X', source)).toBe(false); expect(isOfficialRDAPEntityURL('https://rdap.arin.net/registry/entity/X', source)).toBe(true); });
 it('accepts only official related RDAP referrals for the same domain', () => { const make = (href: string) => ({ links: [{ rel: 'related', type: 'application/rdap+json', href }] }); expect(registrarReferral(make('https://rdap.cloudflare.com/rdap/v1/domain/EXAMPLE.COM'), 'example.com')).toBe('https://rdap.cloudflare.com/rdap/v1/domain/EXAMPLE.COM'); expect(registrarReferral(make('https://127.0.0.1/domain/example.com'), 'example.com')).toBeUndefined(); expect(registrarReferral(make('https://rdap.cloudflare.com/domain/other.com'), 'example.com')).toBeUndefined(); });
 it('uses explicitly network-scoped abuse contacts only when a single network owner is identified', () => { const entities = normalizeRDAP({ objectClassName: 'ip network', entities: [{ roles: ['registrant'], vcardArray: card('Network A') }, { roles: ['abuse'], vcardArray: card('Abuse team', 'network-reports@example.com') }] }, source, '', ''); expect(entities[0]?.contacts[0]).toMatchObject({ type: 'abuse-email', value: 'network-reports@example.com' }); });
});
