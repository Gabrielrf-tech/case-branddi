import { parse } from 'tldts';
import ipaddr from 'ipaddr.js';
export function isPublicIP(value: string): boolean {
  try { const ip = ipaddr.process(value.replace(/^\[|\]$/g, '')); return ip.range() === 'unicast'; } catch { return false; }
}
export function parseTarget(input: string) {
  const originalUrl = input.trim();
  if (!originalUrl || originalUrl.length > 2048) throw new Error('Informe uma URL válida de até 2.048 caracteres.');
  if (/^[a-z][a-z\d+.-]*:/i.test(originalUrl) && !/^https?:\/\//i.test(originalUrl)) throw new Error('Apenas protocolos HTTP e HTTPS são permitidos.');
  let url: URL;
  try { url = new URL(/^https?:\/\//i.test(originalUrl) ? originalUrl : `https://${originalUrl}`); } catch { throw new Error('Informe um domínio ou uma URL válida.'); }
  if (url.username || url.password || !['http:', 'https:'].includes(url.protocol)) throw new Error('URLs com credenciais não são permitidas.');
  const hostname = url.hostname.toLowerCase().replace(/\.$/, '').replace(/^\[|\]$/g, '');
  if (ipaddr.isValid(hostname)) {
    if (!isPublicIP(hostname)) throw new Error('Endereços privados, internos ou reservados não são permitidos.');
    return { originalUrl, hostname, domain: hostname, isIP: true };
  }
  const result = parse(hostname, { allowPrivateDomains: true });
  if (!result.domain || !result.isIcann || /(^|\.)(localhost|local|internal|test|invalid|example|onion)$/.test(hostname) || hostname.split('.').some(p => !/^[a-z\d](?:[a-z\d-]*[a-z\d])?$/.test(p))) throw new Error('Informe um domínio público válido. Endereços internos não são permitidos.');
  return { originalUrl, hostname, domain: result.domain, isIP: false };
}
