import { parseTarget, isPublicIP } from './domain';
import { publicJSON, registerRDAPServers } from './http.server';
import { rdapEndpoint, normalizeRDAP, notificationEntities, resolveRelatedRDAP, registrarReferral } from './rdap.server';
import { addOfficialContacts } from './official-contacts.server';
import { queryDNS, recordTypes } from './dns.server';
import { enrichASN } from './asn.server';
import type { Investigation } from './types';
export async function investigateTarget(input: string): Promise<Investigation> {
  const target = parseTarget(input); const queriedAt = new Date().toISOString();
  const result: Investigation = { ...target, entities: [], dns: [], sources: [], events: [], queriedAt, limitations: ['A hospedagem de origem não pôde ser confirmada. Organizações de IP e ASN podem representar CDN, proxy ou operadoras.', 'ASN consultado via RIPEstat. Team Cymru HTTPS não integrado nesta versão; nenhum endpoint não documentado é utilizado.', 'Contatos protegidos ou não publicados não podem ser identificados. Nenhum conteúdo da URL é acessado.'] };
  async function attempt(name: string, fn: () => Promise<{ url: string; status?: 'ok' | 'empty'; message?: string }>) {
    try { const info = await fn(); result.sources.push({ name, status: info.status ?? 'ok', message: info.message ?? 'Consulta concluída.', url: info.url }); }
    catch (error) { const message = error instanceof Error ? error.message : 'Falha na fonte.'; result.sources.push({ name, url: '', status: message.includes('(404)') ? 'empty' : 'error', message: /timeout|abort/i.test(message) ? 'Tempo limite de consulta excedido.' : message }); }
  }
  await Promise.all([
    ...(!target.isIP ? [attempt('RDAP de domínio', async () => {
      const url = await rdapEndpoint(target.domain, 'domain'); const data = await resolveRelatedRDAP(await publicJSON(url), url);
      result.entities.push(...normalizeRDAP(data, url, queriedAt, `Registro de ${target.domain}`).map(addOfficialContacts));
      const referral = registrarReferral(data, target.domain);
      if (referral) await attempt('RDAP oficial do registrador', async () => {
        registerRDAPServers([referral]);
        const registrarData = await resolveRelatedRDAP(await publicJSON(referral), referral);
        result.entities.push(...normalizeRDAP(registrarData, referral, queriedAt, `Registro de ${target.domain}`).map(addOfficialContacts));
        return { url: referral };
      });
      result.events = (data.events ?? []).map((e: any) => ({ action: e.eventAction, date: e.eventDate }));
      return { url };
    }), ...Object.keys(recordTypes).map(t => attempt(`DNS ${t}`, async () => { const response = await queryDNS(['NS', 'MX', 'TXT'].includes(t) ? target.domain : target.hostname, t as keyof typeof recordTypes); result.dns.push(...response.records); return response; }))] : [])
  ]);
  result.entities = notificationEntities(result.entities);
  return result;
}
export async function enrichInvestigation(result: Investigation): Promise<Investigation> {
  const target = parseTarget(result.originalUrl);
  const queriedAt = result.queriedAt;
  async function attempt(name: string, fn: () => Promise<{ url: string; status?: 'ok' | 'empty' }>) {
    try { const info = await fn(); result.sources.push({ name, status: info.status ?? 'ok', message: 'Consulta concluída.', url: info.url }); }
    catch (error) { const message = error instanceof Error ? error.message : 'Falha na fonte.'; result.sources.push({ name, url: '', status: message.includes('(404)') ? 'empty' : 'error', message: /timeout|abort/i.test(message) ? 'Tempo limite de consulta excedido.' : message }); }
  }
  const ips = [...new Set(target.isIP ? [target.hostname] : result.dns.filter(r => ['A', 'AAAA'].includes(r.type)).map(r => r.value))].filter(isPublicIP);
  if (ips.length > 8) result.limitations.push('Enriquecimento limitado aos primeiros 8 IPs públicos para respeitar as fontes.');
  if (result.dns.some(r => ['A', 'AAAA'].includes(r.type) && !isPublicIP(r.value))) result.limitations.push('IP privado ou reservado retornado pelo DNS foi excluído das consultas.');
  for (let i = 0; i < Math.min(ips.length, 8); i += 2) {
    await Promise.all(ips.slice(i, Math.min(i + 2, 8)).flatMap(ip => [
      attempt(`RDAP IP ${ip}`, async () => {
        const url = await rdapEndpoint(ip, 'ip'); const data = await resolveRelatedRDAP(await publicJSON(url), url);
        const entities = normalizeRDAP(data, url, queriedAt, `Bloco ${data.startAddress ?? ip} – ${data.endAddress ?? ip}`);
        result.entities.push(...entities.map(addOfficialContacts)); return { url };
      }),
      attempt(`ASN ${ip}`, async () => { const entities = await enrichASN(ip, queriedAt); return { url: `https://stat.ripe.net/data/network-info/data.json?resource=${encodeURIComponent(ip)}`, status: entities.length ? 'ok' : 'empty' }; })
    ]));
  }
  result.entities = notificationEntities(result.entities); return result;
}
