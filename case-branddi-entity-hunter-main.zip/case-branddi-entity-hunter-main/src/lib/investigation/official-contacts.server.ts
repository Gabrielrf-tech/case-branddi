import { sortContacts } from './rdap.server';
import type { Entity } from './types';

// Manually reviewed official publication, matched only to the identified legal
// organization; never derive an email or channel from the investigated hostname.
export function addOfficialContacts(entity: Entity): Entity {
  if (!/^cloudflare(?:,?\s+inc\.?)?$/i.test(entity.name.trim())) return entity;
  const source = 'https://www.cloudflare.com/trust-hub/reporting-abuse/';
  const contacts = [...entity.contacts, { type: 'abuse-form' as const, value: 'Formulário de denúncia Cloudflare', url: 'https://abuse.cloudflare.com/', source, label: 'Formulário oficial de abuso' }, { type: 'official-contact' as const, value: source, url: source, source, label: 'Página oficial de denúncia de abuso' }];
  if (entity.category === 'Registrar') contacts.push({ type: 'abuse-email', value: 'registrar-abuse@cloudflare.com', url: 'mailto:registrar-abuse@cloudflare.com', source, label: 'E-mail de abuso do registrador' });
  return { ...entity, contacts: sortContacts(contacts), sources: [...new Set([...entity.sources, source])] };
}