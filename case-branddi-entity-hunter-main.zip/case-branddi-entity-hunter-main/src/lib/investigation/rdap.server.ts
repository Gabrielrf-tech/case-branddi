import ipaddr from 'ipaddr.js';
import { publicJSON, registerRDAPServers, isOfficialRDAPEntityURL } from './http.server';
import type { Category, Contact, Entity } from './types';
import { parseTarget } from './domain';
import { isIdentifiableRecipientName, isUsefulContact, notificationRecipients } from './recipient';
interface Bootstrap { services: [string[], string[]][] }
export async function rdapEndpoint(resource: string, kind: 'domain' | 'ip') {
  const version = kind === 'domain' ? 'dns' : ipaddr.parse(resource).kind() === 'ipv4' ? 'ipv4' : 'ipv6';
  const boot = await publicJSON<Bootstrap>(`https://data.iana.org/rdap/${version}.json`, 86_400_000);
  registerRDAPServers(boot.services.flatMap(([, urls]) => urls));
  const matches = boot.services.filter(([keys]) => keys.some(key => kind === 'domain' ? resource.split('.').at(-1) === key : ipaddr.parse(resource).match(ipaddr.parseCIDR(key))));
  const endpoint = matches.flatMap(([, urls]) => urls).find(u => u.startsWith('https://'));
  if (!endpoint) throw new Error('Nenhum servidor RDAP HTTPS disponível no bootstrap IANA.');
  return `${endpoint.replace(/\/$/, '')}/${kind}/${encodeURIComponent(resource)}`;
}
// Follow only explicitly linked entity records on trusted RDAP servers, never websites.
export async function resolveRelatedRDAP(data: any, source: string) {
  let remaining = 12;
  const seen = new Set<string>();
  async function expand(node: any, depth: number): Promise<any> {
    if (depth > 3) return node;
    let resolved = node;
    if (!node.vcardArray || !(node.entities?.length)) {
      const href = (node.links ?? []).find((l: any) => l.rel === 'self' && l.type === 'application/rdap+json' && isOfficialRDAPEntityURL(l.href, source))?.href;
      if (href && remaining > 0 && !seen.has(href)) {
        seen.add(href); remaining--;
        try { const record = await publicJSON(href); resolved = { ...node, ...record, roles: node.roles ?? record.roles, _contactSource: href }; } catch { /* Keep the original record if the official referral fails. */ }
      }
    }
    const children = [];
    for (const child of resolved.entities ?? []) children.push(await expand(child, depth + 1));
    return { ...resolved, entities: children };
  }
  return expand(data, 0);
}
export function registrarReferral(data: any, domain: string): string | undefined {
  for (const link of data.links ?? []) {
    if (link.rel !== 'related' || link.type !== 'application/rdap+json') continue;
    try {
      const url = new URL(link.href);
      if (url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443') || parseTarget(url.origin).isIP) continue;
      const match = url.pathname.match(/\/domain\/([^/]+)$/i);
      if (match?.[1] && decodeURIComponent(match[1]).toLowerCase() === domain.toLowerCase()) return url.href;
    } catch {}
  }
  return undefined;
}
const rank: Record<Contact['type'], number> = { 'abuse-email': 0, 'notification-email': 1, 'abuse-form': 2, 'official-contact': 3 };
export function sortContacts(contacts: Contact[]) {
  return contacts.filter(isUsefulContact).filter((c, i, list) => list.findIndex(other => other.url === c.url && other.type === c.type) === i).sort((a, b) => rank[a.type] - rank[b.type]);
}
function values(node: any, key: string): string[] {
  return (node.vcardArray?.[1] ?? []).filter((c: any[]) => c[0] === key).map((c: any[]) => Array.isArray(c[3]) ? c[3].flat().filter(Boolean).join(', ') : String(c[3] ?? '')).filter(Boolean);
}
function realName(node: any) { const name = values(node, 'org')[0] || values(node, 'fn')[0] || node.name; return typeof name === 'string' && isIdentifiableRecipientName(name) ? name.trim() : ''; }
function contactsFrom(node: any, source: string): Contact[] {
  const roles: string[] = node.roles ?? [];
  const abuse = roles.includes('abuse');
  const administrative = roles.some(r => ['administrative', 'technical', 'billing', 'noc'].includes(r));
  const provenance = node._contactSource || source;
  const emails = values(node, 'email').filter(email => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !/redacted|not.?disclosed|search-apnic-not-arin/i.test(email));
  const result: Contact[] = emails.map(email => ({ type: abuse ? 'abuse-email' : administrative || /^(admin|technical|noc|registrar-admin)[@-]/i.test(email) ? 'official-contact' : 'notification-email', value: email, url: `mailto:${email}`, source: provenance, label: abuse ? 'E-mail de abuso · RDAP' : administrative || /^(admin|technical|noc|registrar-admin)[@-]/i.test(email) ? `Contato ${roles.join(' / ')} · não é canal de abuso` : 'E-mail publicado · RDAP' }));
  for (const value of [...values(node, 'url'), ...values(node, 'contact-uri')]) {
    try { const url = new URL(value); if (url.protocol === 'https:') result.push({ type: abuse ? 'abuse-form' : 'official-contact', value, url: value, source: provenance, label: abuse ? 'Canal de abuso · RDAP' : 'Canal oficial · RDAP' }); } catch {}
  }
  for (const phone of values(node, 'tel')) if (/^\+?[\d\s().-]{7,}$/.test(phone)) result.push({ type: 'official-contact', value: phone, url: `tel:${phone.replace(/[^+\d]/g, '')}`, source: provenance, label: 'Telefone publicado · RDAP' });
  return result;
}
export function normalizeRDAP(data: any, source: string, queriedAt: string, relation: string): Entity[] {
  const output: Entity[] = [];
  const isNetwork = data.objectClassName === 'ip network';
  function visit(node: any) {
    const roles: string[] = node.roles ?? [];
    const category: Category | undefined = roles.includes('registrar') ? 'Registrar' : roles.includes('registry') ? 'Registry' : roles.includes('registrant') ? isNetwork ? 'ISP' : 'Registrant' : undefined;
    const name = realName(node);
    if (category && name && (!node.objectClassName || node.objectClassName === 'entity')) {
      const contacts = contactsFrom(node, source);
      function collect(child: any, depth: number) {
        if (depth > 3) return;
        const childName = realName(child);
        const childRoles: string[] = child.roles ?? [];
        // An explicitly nested role contact belongs to this organization; a different
        // organization with its own recipient role must be handled independently.
        if (childName && childName !== name && (values(child, 'org')[0] && values(child, 'org')[0] !== name || childRoles.some(r => ['registrar', 'registrant', 'registry'].includes(r)))) return;
        contacts.push(...contactsFrom(child, source));
        for (const nested of child.entities ?? []) collect(nested, depth + 1);
      }
      for (const child of node.entities ?? []) collect(child, 0);
      const ordered = sortContacts(contacts);
      output.push({ id: `${category}:${node.handle || name}`, name, category, categories: [category], relation: `${relation} · ${roles.join(', ')}${isNetwork ? ' · responsável pelo bloco IP; não comprova hospedagem' : ''}`, contacts: ordered, emails: ordered.filter(c => c.type === 'notification-email').map(c => c.value), abuseEmails: ordered.filter(c => c.type === 'abuse-email').map(c => c.value), phones: values(node, 'tel'), address: values(node, 'adr').join('; '), contactUrl: ordered.find(c => c.url.startsWith('https:'))?.url ?? '', sources: [source], queriedAt, notes: (node.remarks ?? []).flatMap((r: any) => r.description ?? []).slice(0, 8), confidence: 'Alta' });
    }
    for (const child of node.entities ?? []) visit(child);
  }
  for (const node of data.entities ?? []) visit(node);
  if (isNetwork && output.filter(entity => entity.category === 'ISP').length === 1) {
    const owner = output.find(entity => entity.category === 'ISP');
    if (owner) {
      // A single identified IP owner and explicitly scoped abuse contact are
      // linked by the same authoritative network record (common at RIPE/APNIC).
      const related = (data.entities ?? []).filter((node: any) => node.roles?.includes('abuse') && (!values(node, 'org')[0] || values(node, 'org')[0] === owner.name));
      owner.contacts = sortContacts([...owner.contacts, ...related.flatMap((node: any) => contactsFrom(node, source))]);
      owner.abuseEmails = owner.contacts.filter(contact => contact.type === 'abuse-email').map(contact => contact.value);
    }
  }
  return output;
}
export function mergeEntities(entities: Entity[]) {
  const merged = new Map<string, Entity>();
  for (const entity of entities) {
    // Never combine contacts across recipient categories on a name-only match.
    const key = `${entity.category}:${entity.id}:${entity.name.toLowerCase()}`;
    const prior = merged.get(key);
    if (!prior) { merged.set(key, { ...entity, contacts: [...entity.contacts] }); continue; }
    prior.contacts = sortContacts([...prior.contacts, ...entity.contacts]);
    for (const field of ['emails', 'abuseEmails', 'phones', 'sources', 'notes', 'categories'] as const) (prior[field] as string[]) = [...new Set([...prior[field], ...entity[field]])];
    prior.address ||= entity.address; prior.contactUrl ||= entity.contactUrl;
    if (!prior.relation.includes(entity.relation)) prior.relation += `; ${entity.relation}`;
  }
  return [...merged.values()];
}
export function notificationEntities(entities: Entity[]) { return notificationRecipients(mergeEntities(entities)); }
