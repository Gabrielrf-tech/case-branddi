import { isPublicIP } from './domain';
const cache = new Map<string, { expires: number; value: unknown }>();
const pending = new Map<string, Promise<unknown>>();
const cooldown = new Map<string, number>();
let active = 0;
const queue: (() => void)[] = [];
const officialRDAPHosts = new Set<string>();
export function registerRDAPServers(urls: string[]) {
  for (const value of urls) { const url = new URL(value); if (url.protocol === 'https:') officialRDAPHosts.add(url.hostname); }
}
export function isOfficialRDAPEntityURL(value: unknown, source: string): boolean {
  if (typeof value !== 'string') return false;
  try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password && (!url.port || url.port === '443') && (officialRDAPHosts.has(url.hostname) || url.hostname === new URL(source).hostname) && /\/entity\/[^/]+/.test(url.pathname); } catch { return false; }
}
export function safeRDAPRedirect(location: string, from: URL): URL {
  const next = new URL(location, from);
  if (next.protocol !== 'https:' || next.username || next.password || (next.port && next.port !== '443') || !officialRDAPHosts.has(next.hostname) || !/\/(ip|domain|entity)\//.test(next.pathname)) throw new Error('Redirecionamento fora dos servidores oficiais IANA bloqueado.');
  return next;
}
export async function publicJSON<T = any>(urlString: string, ttl = 300_000): Promise<T> {
  const url = new URL(urlString);
  if (url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443') || !url.hostname.includes('.') || ( /^[\d.]+$/.test(url.hostname) && !isPublicIP(url.hostname))) throw new Error('Fonte insegura bloqueada.');
  const hit = cache.get(urlString);
  if (hit && hit.expires > Date.now()) return hit.value as T;
  const existing = pending.get(urlString); if (existing) return existing as Promise<T>;
  const task = (async () => {
    if ((cooldown.get(url.origin) ?? 0) > Date.now()) throw new Error('Fonte temporariamente limitada. Tente novamente mais tarde.');
    if (active >= 4) await new Promise<void>(resolve => queue.push(resolve));
    active++;
    try {
      const signal = AbortSignal.timeout(12_000);
      let current = url;
      let response = await fetch(current, { headers: { accept: 'application/rdap+json, application/dns-json, application/json' }, signal, redirect: 'manual' });
      for (let hop = 0; [301, 302, 303, 307, 308].includes(response.status) && hop < 3; hop++) {
        const location = response.headers.get('location');
        if (!location || !officialRDAPHosts.has(current.hostname)) throw new Error('Redirecionamento da fonte bloqueado.');
        current = safeRDAPRedirect(location, current);
        response = await fetch(current, { headers: { accept: 'application/rdap+json' }, signal, redirect: 'manual' });
      }
      if (response.status === 429 || response.status === 503) {
        const after = response.headers.get('retry-after');
        const wait = after ? (/^\d+$/.test(after) ? Number(after) * 1000 : Math.max(0, Date.parse(after) - Date.now())) : 60_000;
        cooldown.set(url.origin, Date.now() + (Number.isFinite(wait) ? wait : 60_000));
      }
      if (!response.ok) throw new Error(response.status === 404 ? 'Nenhum registro encontrado (404).' : `Fonte indisponível (HTTP ${response.status}).`);
      const text = await response.text(); if (text.length > 2_000_000) throw new Error('Resposta excedeu o limite seguro.');
      const value = JSON.parse(text);
      if (cache.size > 256) cache.clear();
      cache.set(urlString, { value, expires: Date.now() + ttl }); return value;
    } finally { active--; queue.shift()?.(); }
  })();
  pending.set(urlString, task);
  try { return await task as T; } finally { pending.delete(urlString); }
}
