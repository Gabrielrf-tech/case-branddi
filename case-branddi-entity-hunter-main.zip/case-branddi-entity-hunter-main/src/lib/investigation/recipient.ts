import ipaddr from 'ipaddr.js';
import { categories, type Contact, type Entity } from './types';

// Recipient eligibility is shared by normalization and the visible result list.
export function isIdentifiableRecipientName(value: string): boolean {
  const name = value.trim();
  if (!name || /^(?:abuse|admin|noc|technical|administrative|registrant|redacted|data redacted|not disclosed|data protected|unknown|organização não informada|.*privacy.*|.*proxy.*|.*whois contact.*)$/i.test(name)) return false;
  const address = name.replace(/^\[|\]$/g, '');
  if (ipaddr.isValid(address)) return false;
  try { ipaddr.parseCIDR(address); return false; } catch { /* Not a CIDR prefix. */ }
  const range = name.split(/\s*[-–—]\s*/);
  if (range.length === 2 && range.every(part => ipaddr.isValid(part.replace(/^\[|\]$/g, '')))) return false;
  return !/^(?:AS\s*\d+(?:\s*[·:-]\s*(?:unknown|organização não informada))?|(?:NET|NET6|INETNUM|INET6NUM|CIDR|IPv[46])(?:$|[\s:_-].*)|(?:ip(?:v[46])?\s+)?(?:network|allocation|address block|bloco|faixa|prefixo)(?:$|[\s:]+[\d:./-].*))$/i.test(name);
}

export function isUsefulContact(contact: Contact): boolean {
  if (!contact.value.trim()) return false;
  try {
    const source = new URL(contact.source);
    if (source.protocol !== 'https:') return false;
    const url = new URL(contact.url);
    if (url.protocol === 'mailto:') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(url.pathname) && !/redacted|not.?disclosed/i.test(url.pathname);
    if (url.protocol === 'tel:') return /^\+?\d{7,}$/.test(url.pathname);
    if (url.protocol !== 'https:' || url.username || url.password || ipaddr.isValid(url.hostname.replace(/^\[|\]$/g, ''))) return false;
    return !/(^|\.)rdap\./i.test(url.hostname) && url.hostname !== 'data.iana.org' && url.hostname !== 'stat.ripe.net'
      && !/\/(?:rdap|ip|domain|entity|autnum)(?:\/|$)/i.test(url.pathname);
  } catch { return false; }
}

export function notificationRecipients(entities: Entity[]): Entity[] {
  return entities.filter(entity => categories.includes(entity.category) && isIdentifiableRecipientName(entity.name))
    .map(entity => ({ ...entity, contacts: entity.contacts.filter(isUsefulContact) }))
    .filter(entity => entity.contacts.length > 0);
}