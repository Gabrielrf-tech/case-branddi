export const categories = ['Domínio', 'Registrant', 'ISP', 'Registrar', 'Registry', 'Hosting Provider'] as const;
export type Category = typeof categories[number];
export interface Contact { type: 'abuse-email' | 'notification-email' | 'abuse-form' | 'official-contact'; value: string; url: string; source: string; label: string; }
export interface Entity { id: string; name: string; category: Category; categories: Category[]; relation: string; contacts: Contact[]; emails: string[]; abuseEmails: string[]; phones: string[]; address: string; contactUrl: string; sources: string[]; queriedAt: string; notes: string[]; confidence: 'Alta' | 'Média'; }
export interface DNSRecord { type: string; name: string; value: string; ttl: number; source: string; }
export interface SourceStatus { name: string; url: string; status: 'ok' | 'empty' | 'error'; message: string; }
export interface Investigation { originalUrl: string; hostname: string; domain: string; entities: Entity[]; dns: DNSRecord[]; sources: SourceStatus[]; events: { action: string; date: string }[]; queriedAt: string; limitations: string[]; }
