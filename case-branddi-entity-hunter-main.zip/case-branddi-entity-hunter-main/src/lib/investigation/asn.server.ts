import { publicJSON } from './http.server';
import type { Entity } from './types';
import { isIdentifiableRecipientName } from './recipient';
export async function enrichASN(ip: string, queriedAt: string): Promise<Entity[]> {
  const url = `https://stat.ripe.net/data/network-info/data.json?resource=${encodeURIComponent(ip)}`;
  const info = await publicJSON(url);
  const organizations = await Promise.all((info.data?.asns ?? []).slice(0, 4).map(async (asn: string): Promise<Entity | null> => {
    const source = `https://stat.ripe.net/data/as-overview/data.json?resource=AS${asn}`;
    const overview = await publicJSON(source);
    const holder = overview.data?.holder;
    if (typeof holder !== 'string' || !isIdentifiableRecipientName(holder)) return null;
    return { id: `AS${asn}`, name: holder.trim(), category: 'ISP' as const, categories: ['ISP' as const], relation: `AS${asn} · rota anunciada para ${ip} · prefixo ${info.data?.prefix ?? 'não informado'}`, contacts: [], emails: [], abuseEmails: [], phones: [], address: '', contactUrl: '', sources: [url, source], queriedAt, notes: [overview.data?.block?.desc || 'Registro regional não informado', 'ASN não comprova a hospedagem de origem.'], confidence: 'Alta' as const };
  }));
  return organizations.filter((entity): entity is Entity => entity !== null);
}
