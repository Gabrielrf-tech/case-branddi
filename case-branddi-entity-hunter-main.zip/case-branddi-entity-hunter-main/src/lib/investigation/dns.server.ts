import { publicJSON } from './http.server';
import type { DNSRecord } from './types';
export const recordTypes = { A: 1, AAAA: 28, NS: 2, MX: 15, TXT: 16, CNAME: 5 };
export async function queryDNS(hostname: string, type: keyof typeof recordTypes) {
  let lastError: unknown;
  for (const base of ['https://cloudflare-dns.com/dns-query', 'https://dns.google/resolve']) {
    const url = `${base}?name=${encodeURIComponent(hostname)}&type=${type}`;
    try {
      const data = await publicJSON(url);
      if (![0, 3].includes(data.Status)) throw new Error(`DNS retornou status ${data.Status}.`);
      const records: DNSRecord[] = (data.Answer ?? []).map((r: any) => ({ type: Object.entries(recordTypes).find(([, n]) => n === r.type)?.[0] ?? String(r.type), name: r.name, value: r.data, ttl: r.TTL, source: url }));
      return { records, url, status: records.length ? 'ok' as const : 'empty' as const, message: data.Status === 3 ? 'Domínio inexistente (NXDOMAIN).' : records.length ? `${records.length} registro(s).` : 'Nenhum registro deste tipo.' };
    } catch (error) { lastError = error; }
  }
  throw lastError;
}
