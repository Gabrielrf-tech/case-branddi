import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { investigateTarget, enrichInvestigation } from './investigation/investigate.server';
import type { Investigation } from './investigation/types';
export const investigate = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => z.object({ url: z.string().min(1).max(2048) }).parse(input))
  .handler(async ({ data }) => investigateTarget(data.url));

// Re-run cached discovery server-side; never trust client-supplied IPs or RDAP URLs.
export const enrich = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => z.object({ url: z.string().min(1).max(2048) }).parse(input))
  .handler(async ({ data }): Promise<Investigation> => enrichInvestigation(await investigateTarget(data.url)));
