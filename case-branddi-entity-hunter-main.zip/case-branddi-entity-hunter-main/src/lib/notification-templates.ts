import { categories, type Category } from './investigation/types';
export const incidents = ['Phishing', 'Uso indevido de marca', 'DMCA / Violação de direitos autorais', 'Parceiro não autorizado', 'Falso suporte', 'Fraude digital', 'Outros'] as const;
export interface NoticeInput { recipient: string; category: Category; incident: string; client: string; brand: string; sameName: boolean; details: string; url: string; }
function originalNotice(input: NoticeInput) {
  const brand = input.sameName ? input.client : input.brand;
  const request = input.category === 'Registrar' || input.category === 'Registry' ? 'Solicitamos a análise do domínio conforme suas políticas de registro e abuso e, se cabível, a adoção das medidas aplicáveis dentro de sua competência.' : input.category === 'Registrant' ? 'Solicitamos a análise desta ocorrência e a regularização ou remoção do material indicado, caso confirmada a irregularidade.' : input.category === 'ISP' ? 'Solicitamos o encaminhamento à equipe responsável por abuso de rede e a análise das medidas cabíveis. Sua relação com a rede não comprova a hospedagem de origem.' : input.category === 'Hosting Provider' ? 'Solicitamos a análise pela equipe de abuso e a avaliação de restrição do conteúdo indicado, conforme suas políticas e os elementos apresentados.' : 'Solicitamos a análise desta ocorrência e, se necessário, o encaminhamento ao responsável competente.';
  const kind = input.incident === incidents[2] ? 'possível violação de direitos autorais' : input.incident.toLowerCase();
  return { title: `${input.incident === incidents[2] ? 'Notificação de direitos autorais' : 'Solicitação de análise'} · ${input.incident} · ${brand || input.client} · ${input.url}`, body: `À equipe de ${input.recipient},\n\nSomos representantes de ${input.client}${brand && brand !== input.client ? `, proprietária da marca ${brand}` : ''}, e encaminhamos para análise uma ocorrência reportada como ${kind}.\n\nURL informada: ${input.url}\nMarca afetada: ${brand}\n\n${input.details.trim() ? `Informações fornecidas pelo analista:\n${input.details.trim()}\n\n` : ''}${request}\n\n${input.incident === incidents[2] ? 'Esta comunicação não substitui uma notificação DMCA formal. Declarações de titularidade, boa-fé, exatidão e assinatura devem ser adicionadas apenas se verificadas pelo responsável.\n\n' : ''}Solicitamos a confirmação de recebimento e o retorno sobre a análise. Podemos fornecer documentação complementar para avaliação.\n\nAtenciosamente,\nRepresentante de ${input.client}` };
}

export interface NoticeTemplate { id: string; incident: string; category: Category; title: string; body: string; original: boolean; }
export const templateStorageKey = 'entity-hunter-templates-v1';
const variableInput: NoticeInput = { recipient: '{{destinatario}}', category: 'Registrar', incident: 'Phishing', client: '{{cliente}}', brand: '{{marca}}', sameName: false, details: '{{detalhes}}', url: '{{url}}' };
export function defaultTemplates(): NoticeTemplate[] {
  return incidents.flatMap(incident => categories.map(category => {
    const notice = originalNotice({ ...variableInput, incident, category });
    return { id: `original:${incident}:${category}`, incident, category, ...notice, original: true };
  }));
}
export function parseStoredTemplates(raw: string | null): NoticeTemplate[] {
  if (!raw) return defaultTemplates();
  try {
    const list: unknown = JSON.parse(raw);
    if (!Array.isArray(list)) return defaultTemplates();
    const valid = list.filter((item): item is NoticeTemplate => !!item && typeof item === 'object' && typeof item.id === 'string' && typeof item.incident === 'string' && item.incident.trim().length > 0 && categories.includes(item.category) && typeof item.title === 'string' && typeof item.body === 'string' && typeof item.original === 'boolean');
    const defaults = defaultTemplates();
    return [...defaults.map(item => valid.find(saved => saved.id === item.id) ?? item), ...valid.filter(item => !defaults.some(d => d.id === item.id))];
  } catch { return defaultTemplates(); }
}
export function saveTemplates(storage: Pick<Storage, 'setItem'>, templates: NoticeTemplate[]) { storage.setItem(templateStorageKey, JSON.stringify(templates)); }
export function restoreTemplate(template: NoticeTemplate): NoticeTemplate {
  return defaultTemplates().find(item => item.id === template.id) ?? template;
}
export function matchingTemplate(templates: NoticeTemplate[], incident: string, category: Category) {
  return templates.find(item => item.incident === incident && item.category === category);
}
export function generateNotice(input: NoticeInput, templates: NoticeTemplate[] = defaultTemplates()) {
  const template = matchingTemplate(templates, input.incident, input.category);
  if (!template) throw new Error('Nenhum modelo salvo para esta ocorrência e categoria. Crie o modelo em Templates.');
  const brand = input.sameName ? input.client : input.brand;
  const variables: Record<string, string> = { destinatario: input.recipient, cliente: input.client, marca: brand, detalhes: input.details.trim(), url: input.url, ocorrencia: input.incident, categoria: input.category };
  // Single pass: text supplied by the analyst is never interpreted as another variable.
  const replace = (text: string) => text.replace(/\{\{(destinatario|cliente|marca|detalhes|url|ocorrencia|categoria)\}\}/g, (_, key: string) => variables[key] ?? '');
  return { title: replace(template.title), body: replace(template.body).replace(`Somos representantes de ${input.client}, proprietária da marca ${input.client}`, `Somos representantes de ${input.client}`) };
}
