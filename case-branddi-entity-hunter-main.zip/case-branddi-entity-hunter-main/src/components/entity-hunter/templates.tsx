import { useState } from 'react';
import { Plus, Save, RotateCcw, Trash2, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { categories, type Category } from '@/lib/investigation/types';
import { defaultTemplates, restoreTemplate, type NoticeTemplate } from '@/lib/notification-templates';
import { useNoticeTemplates } from '@/hooks/use-notice-templates';
export function TemplatesPage() {
  const { templates, ready, error, persist } = useNoticeTemplates();
  const [selected, setSelected] = useState(defaultTemplates()[0]?.id ?? '');
  const [draft, setDraft] = useState<NoticeTemplate | null>(null);
  const [status, setStatus] = useState('');
  const current = draft ?? templates.find(t => t.id === selected);
  const incidents = [...new Set(templates.map(t => t.incident))];
  function choose(template: NoticeTemplate) { if (draft && !window.confirm('Descartar alterações não salvas?')) return; setSelected(template.id); setDraft(null); setStatus(''); }
  function edit(key: keyof NoticeTemplate, value: string) { if (current) { setDraft({ ...current, [key]: value }); setStatus(''); } }
  function create() {
    if (draft && !window.confirm('Descartar alterações não salvas?')) return;
    const template: NoticeTemplate = { id: crypto.randomUUID(), incident: 'Nova ocorrência', category: 'Registrar', title: 'Solicitação de análise · {{marca}} · {{url}}', body: 'À equipe de {{destinatario}},\n\nRepresentamos {{cliente}}.\nMarca afetada: {{marca}}\nURL: {{url}}\nOcorrência: {{ocorrencia}}\n\n{{detalhes}}', original: false };
    setSelected(template.id); setDraft(template); setStatus('');
  }
  function save() {
    if (!current) return;
    if (!current.incident.trim() || !current.title.trim() || !current.body.trim()) { setStatus('Preencha ocorrência, título e corpo.'); return; }
    if (templates.some(t => t.id !== current.id && t.incident === current.incident.trim() && t.category === current.category)) { setStatus('Já existe um modelo para esta ocorrência e categoria. Edite o modelo existente.'); return; }
    const next = { ...current, incident: current.incident.trim() };
    if (persist([...templates.filter(t => t.id !== next.id), next])) { setDraft(null); setStatus('Modelo salvo neste navegador.'); }
  }
  function restore() {
    if (!current || !window.confirm('Restaurar o modelo original? As alterações deste modelo serão substituídas.')) return;
    const original = restoreTemplate(current);
    if (persist(templates.map(t => t.id === current.id ? original : t))) { setDraft(null); setStatus('Modelo original restaurado.'); }
  }
  function remove() {
    if (!current || !window.confirm('Excluir este modelo personalizado?')) return;
    if (persist(templates.filter(t => t.id !== current.id))) { setSelected(defaultTemplates()[0]?.id ?? ''); setDraft(null); setStatus('Modelo excluído.'); }
  }
  return <section className="templates-view fade-in"><div className="section-heading"><h3>Modelos de notificação</h3><Button size="sm" onClick={create} disabled={!ready}><Plus/>Novo modelo</Button></div><div className="templates-grid"><nav className="template-list" aria-label="Modelos de notificação">{incidents.map(incident => <div key={incident}><h3>{incident}</h3>{templates.filter(t => t.incident === incident).map(template => <Button variant="ghost" className={`template-option ${selected === template.id ? 'active' : ''}`} key={template.id} onClick={() => choose(template)}><FileText/>{template.category}{!template.original && <span>Personalizado</span>}</Button>)}</div>)}</nav>{current && <div className="template-editor notice-form"><div className="field-row"><div className="field"><label htmlFor="template-incident">Tipo de ocorrência</label><input id="template-incident" value={current.incident} disabled={current.original} onChange={e => edit('incident', e.target.value)}/></div><div className="field"><label htmlFor="template-category">Categoria do destinatário</label><Select value={current.category} disabled={current.original} onValueChange={value => edit('category', value as Category)}><SelectTrigger id="template-category"><SelectValue/></SelectTrigger><SelectContent>{categories.map(category => <SelectItem value={category} key={category}>{category}</SelectItem>)}</SelectContent></Select></div></div><div className="field"><label htmlFor="template-title">Título do modelo</label><textarea id="template-title" rows={3} value={current.title} onChange={e => edit('title', e.target.value)}/></div><div className="field"><label htmlFor="template-body">Corpo do modelo</label><textarea id="template-body" rows={18} value={current.body} onChange={e => edit('body', e.target.value)}/></div><div className="template-variables">{['destinatario', 'cliente', 'marca', 'url', 'ocorrencia', 'categoria', 'detalhes'].map(variable => <code key={variable}>{`{{${variable}}}`}</code>)}</div><div className="template-actions"><Button onClick={save} disabled={!ready || !draft}><Save/>Salvar alterações</Button>{current.original ? <Button variant="outline" onClick={restore} disabled={!ready}><RotateCcw/>Restaurar original</Button> : <Button variant="outline" onClick={remove}><Trash2/>Excluir modelo</Button>}</div>{(error || status) && <p className={error ? 'error-message' : 'text-sm text-muted-foreground'} role="status">{error || status}</p>}</div>}</div></section>;
}
