import { createContext, useContext, useState, type ReactNode } from 'react';
import type { Investigation } from '@/lib/investigation/types';
import { initialNotice, type NoticeState } from './notification';
import type { View } from './sidebar';
function useWorkspaceState() {
  const [view, setView] = useState<View>('search');
  const [theme, setTheme] = useState('light');
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<Investigation | null>(null);
  const [selected, setSelected] = useState('');
  const [notice, setNotice] = useState<NoticeState>(initialNotice);
  return { view, setView, theme, setTheme, url, setUrl, result, setResult, selected, setSelected, notice, setNotice };
}
const WorkspaceContext = createContext<ReturnType<typeof useWorkspaceState> | null>(null);
export function WorkspaceProvider({ children }: { children: ReactNode }) { const value = useWorkspaceState(); return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>; }
export function useWorkspace() { const value = useContext(WorkspaceContext); if (!value) throw new Error('Workspace provider missing'); return value; }
