import { Crosshair, Search, FileText, Database, ChevronRight, ShieldCheck, Sun, Moon, PanelLeftClose } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from '@tanstack/react-router';
export type View = 'search' | 'results' | 'sources' | 'templates';
export function Sidebar({ view, setView, theme, toggleTheme, open, close, hasResult }: { view: View; setView: (view: View) => void; theme: string; toggleTheme: (theme: string) => void; open: boolean; close: () => void; hasResult: boolean }) {
  const routeNavigate = useNavigate();
  const navigate = (next: View) => { setView(next); close(); void routeNavigate({ to: next === 'templates' ? '/templates' : '/' }); };
 return <aside className={`sidebar ${open ? 'open' : ''}`}>
  <div className="brand"><div className="brand-mark"><Crosshair size={24}/></div><div className="brand-name">ENTITY HUNTER</div><Button className="mobile-menu" variant="ghost" size="icon" aria-label="Fechar menu" onClick={close}><PanelLeftClose/></Button></div>
  <p className="brand-subtitle">Domain & Infrastructure<br/>Investigation</p>
  <p className="sidebar-label">WORKSPACE</p>
  <nav className="sidebar-nav" aria-label="Navegação principal">
   <Button variant="ghost" className={`nav-button ${view === 'search' ? 'active' : ''}`} onClick={() => navigate('search')}><Search/>Nova investigação{view === 'search' && <ChevronRight className="nav-arrow"/>}</Button>
   <Button variant="ghost" className={`nav-button ${view === 'results' ? 'active' : ''}`} onClick={() => navigate('results')} disabled={!hasResult}><FileText/>Resultados{view === 'results' && <ChevronRight className="nav-arrow"/>}</Button>
   <Button variant="ghost" className={`nav-button ${view === 'sources' ? 'active' : ''}`} onClick={() => navigate('sources')}><Database/>Fontes de dados{view === 'sources' && <ChevronRight className="nav-arrow"/>}</Button>
    <Button variant="ghost" className={`nav-button ${view === 'templates' ? 'active' : ''}`} onClick={() => navigate('templates')}><FileText/>Templates{view === 'templates' && <ChevronRight className="nav-arrow"/>}</Button>
  </nav>
  <div className="sidebar-bottom"><div className="private-note"><ShieldCheck/><span>Investigação responsável.<br/>Dados públicos, sem acesso ao<br/>conteúdo do site.</span></div>
   <div className="theme-controls" aria-label="Tema"><Button variant="ghost" className={`theme-button ${theme === 'light' ? 'chosen' : ''}`} aria-pressed={theme === 'light'} onClick={() => toggleTheme('light')}><Sun/>Light</Button><Button variant="ghost" className={`theme-button ${theme === 'dark' ? 'chosen' : ''}`} aria-pressed={theme === 'dark'} onClick={() => toggleTheme('dark')}><Moon/>Dark</Button></div>
   <div className="sidebar-version"><span><i className="status-dot"/>Fontes públicas</span><span>v1.0</span></div>
  </div>
 </aside>;
}
