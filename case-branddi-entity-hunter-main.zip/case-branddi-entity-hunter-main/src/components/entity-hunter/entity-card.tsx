import { Building2, Check, Circle, Mail, Phone, ExternalLink, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Entity } from '@/lib/investigation/types';
export function EntityCard({ entity, selected, onSelect }: { entity: Entity; selected: boolean; onSelect: () => void }) {
 return <article className={`entity-card ${selected ? 'selected' : ''}`}><div className="entity-top"><div className="process-icon"><Building2/></div><div><h4>{entity.name}</h4>{entity.categories.map(category => <span className="category-tag" key={category}>{category}</span>)}</div><Button variant={selected ? 'default' : 'outline'} size="icon" className="entity-select" title={selected ? 'Entidade selecionada' : 'Selecionar destinatário'} aria-label={`Selecionar ${entity.name}`} aria-pressed={selected} onClick={onSelect}>{selected ? <Check/> : <Circle/>}</Button></div>
 {entity.contacts.map((contact, index) => <div className="entity-contact" key={`${contact.type}:${contact.url}`}><div className="entity-data">{contact.type === 'abuse-email' || contact.type === 'abuse-form' ? <ShieldAlert/> : contact.url.startsWith('tel:') ? <Phone/> : contact.url.startsWith('https:') ? <ExternalLink/> : <Mail/>}<div><span className="contact-type">{index === 0 ? 'Prioritário · ' : ''}{contact.label}</span><a href={contact.url} target={contact.url.startsWith('https:') ? '_blank' : undefined} rel="noopener noreferrer">{contact.value}</a></div></div></div>)}
 </article>;
}
