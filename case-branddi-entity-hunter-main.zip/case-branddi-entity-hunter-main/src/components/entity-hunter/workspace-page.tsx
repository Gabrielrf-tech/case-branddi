import { useServerFn } from '@tanstack/react-start';
import { useEffect, useState } from 'react';
import { ChevronRight, PanelLeft, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sidebar, type View } from '@/components/entity-hunter/sidebar';
import { SearchPage, SearchForm, PageHeading } from '@/components/entity-hunter/search';
import { ResultsPage, SourcesPage, LoadingPage } from '@/components/entity-hunter/results';
import { useWorkspace } from '@/components/entity-hunter/workspace-context';
import { TemplatesPage } from '@/components/entity-hunter/templates';
import { investigate, enrich } from '@/lib/investigation.functions';
import { parseTarget } from '@/lib/investigation/domain';
import type { Entity } from '@/lib/investigation/types';
export function WorkspacePage({ templatesView = false }: { templatesView?: boolean }) {
 const workspace = useWorkspace();
 const { setView, theme, setTheme, url, setUrl, result, setResult, selected, setSelected, notice, setNotice } = workspace;
 const view: View = templatesView ? 'templates' : workspace.view === 'templates' ? 'search' : workspace.view;
 const [menu, setMenu] = useState(false);
 const [error, setError] = useState(''); const [loading, setLoading] = useState(false); const [stage, setStage] = useState(0);
 const investigateFn = useServerFn(investigate);
 const enrichFn = useServerFn(enrich);
 useEffect(() => { try { const saved = localStorage.getItem('entity-hunter-theme'); if (saved === 'dark') { setTheme('dark'); document.documentElement.classList.add('dark'); } } catch {} }, []);
 function changeTheme(next: string) { setTheme(next); document.documentElement.classList.toggle('dark', next === 'dark'); try { localStorage.setItem('entity-hunter-theme', next); } catch {} }
 async function search() {
  setError(''); setStage(0);
  try { parseTarget(url); } catch (error) { setError(error instanceof Error ? error.message : 'URL inválida.'); return; }
  setLoading(true); setView('search');
  const timer = setTimeout(() => setStage(1), 200);
  try {
   const discovered = await investigateFn({ data: { url } });
   clearTimeout(timer); setStage(2);
   let data = discovered;
   try { data = await enrichFn({ data: { url } }); }
   catch { data.sources.push({ name: 'Enriquecimento IP e ASN', status: 'error', url: '', message: 'Enriquecimento indisponível. Dados de domínio e DNS preservados.' }); }
   setStage(3); setResult(data); setSelected(''); setNotice(old => ({ ...old, recipient: '', category: 'Domínio' })); setView('results');
  }
  catch (error) { setError(error instanceof Error ? error.message : 'Falha na consulta. Tente novamente.'); }
  finally { clearTimeout(timer); setLoading(false); }
 }
 function select(entity: Entity) { setSelected(entity.id); setNotice(old => ({ ...old, recipient: entity.name, category: entity.category })); }
 const title = view === 'templates' ? 'Templates' : view === 'search' ? 'Nova investigação' : view === 'results' ? 'Resultados da investigação' : 'Fontes de dados';
 return <div className="app-shell"><Sidebar view={view} setView={setView} theme={theme} toggleTheme={changeTheme} open={menu} close={() => setMenu(false)} hasResult={!!result}/><div className="main-area"><header className="topbar"><div className="breadcrumbs"><Button variant="ghost" size="icon" className="mobile-menu" aria-label="Abrir menu" onClick={() => setMenu(!menu)}><PanelLeft/></Button><span>Workspace</span><ChevronRight size={11}/><strong>{title}</strong></div><div className="workspace-label"><ShieldCheck/><span>Proteção de marcas</span><i className="status-dot"/></div></header><main className="page-content"><PageHeading title={title} description={view === 'templates' ? 'Modelos de notificação por ocorrência e destinatário.' : view === 'search' ? 'O ponto de partida para uma investigação mais precisa.' : view === 'results' ? 'Entidades, evidências e a sua próxima ação.' : 'Transparência em cada consulta e em cada identificação.'}/>{view === 'templates' ? <TemplatesPage/> : loading ? <LoadingPage stage={stage}/> : view === 'search' ? <SearchPage url={url} setUrl={setUrl} onSearch={search} error={error} loading={loading}/> : view === 'results' && result ? <><div className="results-search"><SearchForm url={url} setUrl={setUrl} onSearch={search} error={error} loading={loading}/></div><ResultsPage result={result} selected={selected} select={select} notice={notice} setNotice={setNotice}/></> : <SourcesPage result={result}/>}<footer className="app-footer"><span>ENTITY HUNTER · Domain & Infrastructure Investigation</span><span>Dados públicos. Decisões responsáveis.</span></footer></main></div></div>;
}
