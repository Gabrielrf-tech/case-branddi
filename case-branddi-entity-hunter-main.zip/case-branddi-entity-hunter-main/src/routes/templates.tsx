import { createFileRoute } from '@tanstack/react-router';
import { WorkspacePage } from '@/components/entity-hunter/workspace-page';
export const Route = createFileRoute('/templates')({
  head: () => ({ meta: [
    { title: 'Templates de notificação · Entity Hunter' },
    { name: 'description', content: 'Edite, salve e restaure modelos de notificação por ocorrência e destinatário no Entity Hunter.' },
    { property: 'og:title', content: 'Templates de notificação · Entity Hunter' },
    { property: 'og:description', content: 'Modelos personalizados de notificação para investigação digital e proteção de marcas.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: () => <WorkspacePage templatesView />,
});
