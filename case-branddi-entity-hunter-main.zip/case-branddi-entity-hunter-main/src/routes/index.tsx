import { createFileRoute } from '@tanstack/react-router';
import { WorkspacePage } from '@/components/entity-hunter/workspace-page';
export const Route = createFileRoute('/')({
 head: () => ({ meta: [{ title: 'Entity Hunter · Investigação de domínios' }, { name: 'description', content: 'Investigue domínios e infraestrutura com RDAP, DNS e ASN públicos. Identifique entidades e prepare notificações personalizadas.' }, { property: 'og:title', content: 'Entity Hunter · Investigação de domínios' }, { property: 'og:description', content: 'Inteligência de infraestrutura digital e notificações para proteção de marcas.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] }),
 component: WorkspacePage,
});
